import jsPDF from 'jspdf';

export function exportLaporanStrategiPDF({
  namaDriver,
  periode,
  totalOrder,
  wilayahFavorit,
  jamTersibuk,
  detail,
}: {
  namaDriver: string;
  periode: string;
  totalOrder: number;
  wilayahFavorit: string;
  jamTersibuk: string;
  detail: Array<{ wilayah: string; jam: string; jumlah: number; spot: string }>;
}): void {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 15;
  let y = margin;

  // Header - style rekening koran bank
  doc.setFillColor(9, 13, 22); // #090d16
  doc.rect(0, 0, pageWidth, 28, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.text('Laporan Analisis Spot & Waktu', margin, y + 8);

  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text(`Driver: ${namaDriver}`, margin, y + 16);
  doc.text(`Periode: ${periode}`, margin + 70, y + 16);
  doc.text('© OpenStreetMap contributors', margin, y + 24);

  y += 40;

  // Ringkasan
  doc.setTextColor(255, 255, 255);
  doc.setFillColor(16, 32, 48);
  doc.rect(margin, y, pageWidth - 2 * margin, 30, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.text('Ringkasan', margin + 8, y + 8);

  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.text(`Total Orderan: ${totalOrder}`, margin + 8, y + 16);
  doc.text(`Wilayah Favorit: ${wilayahFavorit}`, margin + 8, y + 22);
  doc.text(`Jam Tersibuk: ${jamTersibuk}`, margin + 8, y + 28);

  y += 42;

  // Tabel Detail
  doc.setTextColor(15, 23, 35);
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text('Detail Spot Orderan', margin, y);
  y += 8;

  // Table header
  const tableStartY = y;
  const colX = [margin, margin + 30, margin + 70, margin + 100, margin + 140];
  const headers = ['Wilayah', 'Jam', 'Jumlah', 'Spot / Jalan'];

  doc.setFillColor(22, 38, 55);
  doc.rect(margin, tableStartY, pageWidth - 2 * margin, 8, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(8.5);
  doc.setFont('helvetica', 'bold');
  headers.forEach((h, i) => {
    doc.text(h, colX[i] + 2, tableStartY + 5.5);
  });

  y = tableStartY + 10;

  // Table rows
  doc.setFontSize(8.5);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(15, 23, 35);

  detail.forEach((row, idx) => {
    const rowHeight = 7;
    const isEven = idx % 2 === 0;
    if (isEven) {
      doc.setFillColor(242, 245, 248);
      doc.rect(margin, y, pageWidth - 2 * margin, rowHeight, 'F');
    }

    doc.text(row.wilayah, colX[0] + 2, y + 4.5);
    doc.text(row.jam, colX[1] + 2, y + 4.5);
    doc.text(String(row.jumlah), colX[2] + 2, y + 4.5);
    doc.text(row.spot, colX[3] + 2, y + 4.5);

    y += rowHeight;
  });

  // Footer
  y += 10;
  doc.setTextColor(100, 110, 120);
  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  doc.text(
    'Dibuat oleh OjolTarget Pro v1.9.0 - Data lokal pada perangkat',
    margin,
    y
  );
  doc.text('Data geolokasi via Nominatim / OpenStreetMap', margin + 120, y);

  const fileName = `Laporan_Strategi_${periode.replace(/\s/g, '_')}.pdf`;
  doc.save(fileName);
}
