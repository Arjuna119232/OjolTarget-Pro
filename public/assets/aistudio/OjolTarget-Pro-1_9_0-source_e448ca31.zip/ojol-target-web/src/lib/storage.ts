import { STORAGE_KEYS } from '@/types';

const STORAGE_PREFIX = 'ojol_target_';

export function getKey(key: string): string {
  return `${STORAGE_PREFIX}${key}`;
}

export function loadJSON<T>(key: string, fallback: T): T {
  if (typeof window === 'undefined') return fallback;
  try {
    const raw = localStorage.getItem(getKey(key));
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

export function saveJSON<T>(key: string, value: T): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(getKey(key), JSON.stringify(value));
  } catch (e) {
    console.error(`Gagal menyimpan ${key}:`, e);
  }
}

export function removeJSON(key: string): void {
  if (typeof window === 'undefined') return;
  localStorage.removeItem(getKey(key));
}

// Service storage
export function loadServices(): import('@/types').ServiceRecord[] {
  return loadJSON(STORAGE_KEYS.SERVICES, []);
}
export function saveServices(services: import('@/types').ServiceRecord[]): void {
  saveJSON(STORAGE_KEYS.SERVICES, services);
}

// Service settings
export function loadServiceSettings(): import('@/types').ServiceSetting[] {
  return loadJSON(STORAGE_KEYS.SERVICE_SETTINGS, [
    { type: 'Oli', intervalKM: 5000, aktif: true },
    { type: 'Mesin', intervalKM: 20000, aktif: true },
    { type: 'Kopling', intervalKM: 40000, aktif: true },
    { type: 'Rem', intervalKM: 15000, aktif: true },
    { type: 'Aki', intervalKM: 24000, aktif: true },
    { type: 'Filter', intervalKM: 10000, aktif: true },
  ]);
}
export function saveServiceSettings(settings: import('@/types').ServiceSetting[]): void {
  saveJSON(STORAGE_KEYS.SERVICE_SETTINGS, settings);
}

// Orders
export function loadOrders(): import('@/types').OrderRecord[] {
  return loadJSON(STORAGE_KEYS.ORDERS, []);
}
export function saveOrders(orders: import('@/types').OrderRecord[]): void {
  saveJSON(STORAGE_KEYS.ORDERS, orders);
}

// Widget snapshot
export function loadWidgetSnapshot(): import('@/types').WidgetSnapshot | null {
  return loadJSON(STORAGE_KEYS.WIDGET_SNAPSHOT, null);
}
export function saveWidgetSnapshot(snap: import('@/types').WidgetSnapshot): void {
  saveJSON(STORAGE_KEYS.WIDGET_SNAPSHOT, snap);
}

// Onboarding
export function loadOnboarding(): import('@/types').OnboardingData | null {
  return loadJSON(STORAGE_KEYS.ONBOARDING, null);
}
export function saveOnboarding(data: import('@/types').OnboardingData): void {
  saveJSON(STORAGE_KEYS.ONBOARDING, data);
}

// Timer on-bid
export function loadTimerOnBid(): import('@/types').TimerOnBidState {
  return loadJSON(STORAGE_KEYS.TIMER_ONBID, {
    isRunning: false,
    startTime: null,
    elapsedSeconds: 0,
    totalSeconds: 0,
    targetJam: 250,
  });
}
export function saveTimerOnBid(state: import('@/types').TimerOnBidState): void {
  saveJSON(STORAGE_KEYS.TIMER_ONBID, state);
}

// Spot data
export function loadSpotData(): import('@/types').SpotData[] {
  return loadJSON(STORAGE_KEYS.SPOT_DATA, []);
}
export function saveSpotData(spots: import('@/types').SpotData[]): void {
  saveJSON(STORAGE_KEYS.SPOT_DATA, spots);
}

// User settings (includes quick order nominal)
export type { UserSettings } from '@/types';
export function loadUserSettings(): import('@/types').UserSettings {
  return loadJSON(STORAGE_KEYS.USER_SETTINGS, { quickOrderNominal: 10200, platform: '' });
}
export function saveUserSettings(settings: import('@/types').UserSettings): void {
  saveJSON(STORAGE_KEYS.USER_SETTINGS, settings);
}
