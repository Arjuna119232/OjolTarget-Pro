import { LEVEL_TARGETS, GrabLevel, LevelProgress } from '@/types';

export function getDaysInMonth(date: Date = new Date()): number {
  return new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
}

export function getDaysRemainingInMonth(date: Date = new Date()): number {
  const today = date.getDate();
  const total = getDaysInMonth(date);
  return Math.max(0, total - today);
}

export function hitungSisaHari(date: Date = new Date()): number {
  return getDaysRemainingInMonth(date);
}

export function computeLevelProgress(
  level: GrabLevel,
  current: {
    hariOnline: number;
    jamOnline: number;
    penyelesaian: number;
    rating: number;
    orderan: number;
  },
  date: Date = new Date()
): LevelProgress {
  const target = LEVEL_TARGETS[level];
  const daysRemaining = getDaysRemainingInMonth(date);

  // Proyeksi harian untuk hari (hitung hingga akhir bulan)
  const hariProyeksi = Math.min(
    target.hari,
    current.hariOnline + daysRemaining
  );

  return {
    hari: Math.min(target.hari, current.hariOnline),
    jam: Math.min(target.jam, current.jamOnline),
    penyelesaian: Math.min(target.penyelesaian, current.penyelesaian),
    rating: Math.min(target.rating, current.rating),
    orderan: Math.min(target.orderan, current.orderan),
  };
}

export function getLevelIndicatorColor(
  level: GrabLevel,
  progress: LevelProgress,
  current: {
    hariOnline: number;
    jamOnline: number;
    penyelesaian: number;
    rating: number;
    orderan: number;
  }
): 'merah' | 'kuning' | 'hijau' | 'pelangi' {
  const target = LEVEL_TARGETS[level];

  // Hitung persentase capaian keseluruhan (rata-rata 5 kriteria)
  const pctHari = current.hariOnline / target.hari;
  const pctJam = current.jamOnline / target.jam;
  const pctPenyelesaian = current.penyelesaian / target.penyelesaian;
  const pctRating = current.rating / target.rating;
  const pctOrderan = current.orderan / target.orderan;

  const avgPct = (pctHari + pctJam + pctPenyelesaian + pctRating + pctOrderan) / 5;

  if (avgPct >= 0.9) return 'hijau';
  if (avgPct >= 0.5) return 'pelangi';
  if (avgPct >= 0.15) return 'kuning';
  return 'merah';
}

export function getLevelColor(level: GrabLevel): string {
  switch (level) {
    case 'Pejuang': return '#ef4444'; // red-500
    case 'Kesatria': return '#eab308'; // yellow-500
    case 'Jawara': return '#22c55e'; // green-500
  }
}

export function getProgressColor(pct: number): string {
  if (pct >= 100) return '#22c55e';
  if (pct >= 60) return '#22c55e';
  if (pct >= 30) return '#eab308';
  return '#ef4444';
}
