const NOMINATIM_BASE = 'https://nominatim.openstreetmap.org/reverse';
const USER_AGENT = 'OjolTargetPro/1.9.0 (support@ojoltarget.pro)';

let lastRequestTime = 0;
const MIN_INTERVAL_MS = 1100; // 1 request per detik

export async function getNamaLokasi(lat: number, lng: number): Promise<{
  nama: string;
  wilayah: string;
  isEstimasi: boolean;
  displayName: string;
}> {
  // Rate limiting
  const now = Date.now();
  const wait = MIN_INTERVAL_MS - (now - lastRequestTime);
  if (wait > 0) {
    await new Promise((r) => setTimeout(r, wait));
  }
  lastRequestTime = Date.now();

  try {
    const resp = await fetch(
      `${NOMINATIM_BASE}?format=json&lat=${lat}&lon=${lng}&accept-language=id`,
      {
        headers: { 'User-Agent': USER_AGENT },
        signal: AbortSignal.timeout(8000),
      }
    );
    if (!resp.ok) throw new Error(`Nominatim ${resp.status}`);
    const data = await resp.json();
    lastRequestTime = Date.now();

    const addr = data.address || {};
    const kelurahan = addr.suburb || addr.neighbourhood || addr.quarter || '';
    const kecamatan = addr.city_district || addr.borough || '';
    const kota = addr.city || addr.municipality || addr.town || '';
    const provinsi = addr.state || '';

    let nama = '';
    if (addr.road) nama += addr.road;
    if (kelurahan) nama += nama ? `, ${kelurahan}` : kelurahan;
    if (kecamatan) nama += nama ? `, ${kecamatan}` : kecamatan;
    if (!nama) nama = data.display_name || 'Lokasi Tidak Diketahui';

    const wilayah = deteksiWilayah(lat, lng, kota);

    return {
      nama: nama || 'Lokasi Tidak Diketahui',
      wilayah,
      isEstimasi: false,
      displayName: data.display_name || nama,
    };
  } catch (err) {
    console.warn('Nominatim gagal, fallback bounding box:', err);
    const wilayah = deteksiWilayah(lat, lng, '');
    return {
      nama: `Lokasi (${lat.toFixed(4)}, ${lng.toFixed(4)})`,
      wilayah,
      isEstimasi: true,
      displayName: `Perkiraan: ${wilayah}`,
    };
  }
}

// Bounding box DKI Jakarta (approx)
const JAKARTA_BBOX = {
  latMin: -6.30,
  latMax: -6.05,
  lngMin: 106.65,
  lngMax: 107.00,
};

const JAKARTA_WILAYAH_MAP: Record<string, string> = {
  'Jakarta Selatan': 'Jaksel',
  'Jakarta Barat': 'Jakbar',
  'Jakarta Pusat': 'Jakpus',
  'Jakarta Timur': 'Jaktim',
  'Jakarta Utara': 'Jakut',
};

export function deteksiWilayah(lat: number, lng: number, kota: string): string {
  if (kota && JAKARTA_WILAYAH_MAP[kota]) {
    return JAKARTA_WILAYAH_MAP[kota];
  }
  if (
    lat >= JAKARTA_BBOX.latMin &&
    lat <= JAKARTA_BBOX.latMax &&
    lng >= JAKARTA_BBOX.lngMin &&
    lng <= JAKARTA_BBOX.lngMax
  ) {
    // Approximate quadrant split
    const latMid = (JAKARTA_BBOX.latMin + JAKARTA_BBOX.latMax) / 2;
    const lngMid = (JAKARTA_BBOX.lngMin + JAKARTA_BBOX.lngMax) / 2;
    const isSouth = lat > latMid; // more negative = south
    const isEast = lng > lngMid;

    if (isSouth && isEast) return 'Jaksel';
    if (isSouth && !isEast) return 'Jakbar';
    if (!isSouth && isEast) return 'Jaktim';
    if (!isSouth && !isEast) return 'Jakpus';
  }
  return 'Luar Jakarta';
}

export function getJamGacorSlot(date: Date = new Date()): string {
  const h = date.getHours();
  if (h >= 6 && h < 9) return '06:00-09:00';
  if (h >= 9 && h < 11) return '09:00-11:00';
  if (h >= 11 && h < 13) return '11:00-13:00';
  if (h >= 13 && h < 17) return '13:00-17:00';
  if (h >= 17 && h < 20) return '17:00-20:00';
  if (h >= 20 && h < 23) return '20:00-23:00';
  return '23:00-06:00';
}

export function formatRupiah(val: number): string {
  return new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency: 'IDR',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(val);
}

export function formatKM(val: number): string {
  return `${val.toLocaleString('id-ID')} KM`;
}
