import { formatRupiah } from './nominatim';

export function hitungSisaKM(
  currentKM: number,
  kmAtServis: number,
  intervalKM: number
): { sisa: number; targetKM: number; pct: number } {
  const targetKM = kmAtServis + intervalKM;
  const sisa = Math.max(0, targetKM - currentKM);
  const pct = Math.min(100, Math.round(((currentKM - kmAtServis) / intervalKM) * 100));
  return { sisa, targetKM, pct };
}

export function servisTerdekat(
  services: import('@/types').ServiceRecord[],
  currentKM: number
): { servis: import('@/types').ServiceRecord | null; sisaKM: number } {
  if (!services.length) return { servis: null, sisaKM: 0 };

  // Hitung sisa KM untuk setiap servis aktif berdasarkan jenisnya
  let terdekat: import('@/types').ServiceRecord | null = null;
  let minSisa = Infinity;

  for (const s of services) {
    // Cari interval berdasarkan jenis servis
    const interval = getIntervalForType(s.type);
    const targetKM = s.kmAtServis + interval;
    const sisa = Math.max(0, targetKM - currentKM);
    if (sisa < minSisa) {
      minSisa = sisa;
      terdekat = s;
    }
  }

  return { servis: terdekat, sisaKM: minSisa === Infinity ? 0 : minSisa };
}

function getIntervalForType(type: import('@/types').ServiceType): number {
  const intervals: Record<import('@/types').ServiceType, number> = {
    Oli: 5000,
    Mesin: 20000,
    Kopling: 40000,
    Rem: 15000,
    Aki: 24000,
    Filter: 10000,
  };
  return intervals[type] || 5000;
}

export function formatSisaKM(sisa: number): string {
  if (sisa <= 0) return 'Servis sudah jatuh tempo';
  return formatRupiah(0).replace('Rp', '') + ` Sisa ${sisa.toLocaleString('id-ID')} KM`;
}
