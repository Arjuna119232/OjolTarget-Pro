interface NativeGeoBridge {
  requestLocation?: () => void;
}

/**
 * Meminta izin lokasi ke Android (runtime permission) lalu mengambil koordinat
 * lewat navigator.geolocation. WebView geolocation prompt sudah di-grant di
 * sisi native (onGeolocationPermissionsShowPrompt).
 */
export async function getCurrentPositionOnce(
  timeoutMs = 12000
): Promise<{ lat: number; lng: number }> {
  const bridge = (window as any).OjolNative as NativeGeoBridge | undefined;
  try {
    bridge?.requestLocation?.();
  } catch {
    /* bridge tidak tersedia di browser biasa */
  }

  const waitPermission = async () => {
    // Beri waktu dialog izin muncul & diputuskan.
    if (navigator.permissions?.query) {
      try {
        const status = await navigator.permissions.query({ name: 'geolocation' as PermissionName });
        if (status.state === 'denied') {
          throw new Error('Izin lokasi ditolak');
        }
        if (status.state === 'prompt') {
          await new Promise((r) => setTimeout(r, 1200));
        }
      } catch {
        /* abaikan, lanjut coba */
      }
    } else {
      await new Promise((r) => setTimeout(r, 1200));
    }
  };

  await waitPermission();

  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new Error('Geolocation tidak didukung'));
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => resolve({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
      (err) => reject(new Error(err.message || 'Gagal mengambil lokasi')),
      { enableHighAccuracy: true, timeout: timeoutMs, maximumAge: 30000 }
    );
  });
}
