import { useState, useCallback, useEffect } from 'react';
import { loadSpotData, saveSpotData } from '@/lib/storage';
import { getNamaLokasi, getJamGacorSlot } from '@/lib/nominatim';
import { SpotData } from '@/types';

export function useSpotData() {
  const [spots, setSpots] = useState<SpotData[]>(() => loadSpotData());
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    saveSpotData(spots);
  }, [spots]);

  const addSpot = useCallback(
    async (lat: number, lng: number, manualNama?: string, manualWilayah?: string) => {
      setLoading(true);
      try {
        let nama: string;
        let wilayah: string;
        let isEstimasi = false;

        if (manualNama) {
          nama = manualNama;
          wilayah = manualWilayah || 'Luar Jakarta';
          isEstimasi = true;
        } else {
          const result = await getNamaLokasi(lat, lng);
          nama = result.nama;
          wilayah = result.wilayah;
          isEstimasi = result.isEstimasi;
        }

        const spot: SpotData = {
          id: crypto.randomUUID(),
          lat,
          lng,
          timestamp: Date.now(),
          namaLokasi: nama,
          wilayah,
          jamGacor: getJamGacorSlot(),
          isEstimasi,
        };

        setSpots((prev) => [spot, ...prev]);
        return spot;
      } finally {
        setLoading(false);
      }
    },
    []
  );

  const clearSpots = useCallback(() => setSpots([]), []);

  return { spots, loading, addSpot, clearSpots, setSpots };
}
