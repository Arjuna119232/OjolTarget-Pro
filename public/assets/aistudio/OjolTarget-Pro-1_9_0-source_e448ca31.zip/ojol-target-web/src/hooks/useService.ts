import { useState, useCallback, useEffect } from 'react';
import {
  loadServices,
  saveServices,
  loadServiceSettings,
  saveServiceSettings,
} from '@/lib/storage';
import { ServiceRecord, ServiceSetting, ServiceType, SERVICE_INTERVALS } from '@/types';

export function useService() {
  const [services, setServices] = useState<ServiceRecord[]>(() => loadServices());
  const [settings, setSettings] = useState<ServiceSetting[]>(() => loadServiceSettings());

  useEffect(() => {
    saveServices(services);
  }, [services]);

  useEffect(() => {
    saveServiceSettings(settings);
  }, [settings]);

  /**
   * Menambahkan catatan servis baru. KM dihitung mulai dari 0 untuk kategori
   * ini (kmAtServis = currentKM), sehingga hitungan sisa KM ter-reset.
   */
  const addService = useCallback(
    (type: ServiceType, currentKM: number, catatan = '') => {
      const interval = SERVICE_INTERVALS[type];
      const record: ServiceRecord = {
        id: crypto.randomUUID(),
        type,
        kmAtServis: currentKM,
        currentKM,
        kmSisa: interval,
        targetKM: currentKM + interval,
        catatan,
        tanggal: new Date().toISOString(),
        createdAt: Date.now(),
      };
      setServices((prev) => [record, ...prev]);
      return record;
    },
    []
  );

  const removeService = useCallback((id: string) => {
    setServices((prev) => prev.filter((s) => s.id !== id));
  }, []);

  return { services, settings, addService, removeService, setServices, setSettings };
}
