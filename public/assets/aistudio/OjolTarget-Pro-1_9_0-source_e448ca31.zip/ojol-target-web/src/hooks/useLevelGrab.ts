import { useState, useCallback } from 'react';
import { LEVEL_TARGETS, GrabLevel, LevelProgress } from '@/types';
import { computeLevelProgress, getLevelIndicatorColor, getLevelColor } from '@/lib/level';

export function useLevelGrab() {
  const [level, setLevel] = useState<GrabLevel | null>(null);
  const [current, setCurrent] = useState({
    hariOnline: 0,
    jamOnline: 0,
    penyelesaian: 0,
    rating: 0,
    orderan: 0,
  });

  const progress = level ? computeLevelProgress(level, current) : null;
  const color = level && progress ? getLevelIndicatorColor(level, progress, current) : null;
  const levelColor = level ? getLevelColor(level) : '#64748b';

  const updateCurrent = useCallback((updates: Partial<typeof current>) => {
    setCurrent((prev) => ({ ...prev, ...updates }));
  }, []);

  const setLevelSelection = useCallback((l: GrabLevel | null) => {
    setLevel(l);
  }, []);

  const hitungSisaHari = () => {
    const now = new Date();
    const end = new Date(now.getFullYear(), now.getMonth() + 1, 0);
    return Math.max(0, end.getDate() - now.getDate());
  };

  return {
    level,
    current,
    progress,
    color,
    levelColor,
    setLevel: setLevelSelection,
    updateCurrent,
    hitungSisaHari,
    targets: LEVEL_TARGETS,
  };
}
