import { useState, useCallback, useEffect } from 'react';
import {
  loadUserSettings,
  saveUserSettings,
  loadWidgetSnapshot,
  saveWidgetSnapshot,
} from '@/lib/storage';
import { WidgetSnapshot, UserSettings } from '@/types';
import { formatRupiah } from '@/lib/nominatim';

export function useQuickOrder() {
  const [settings, setSettings] = useState<UserSettings>(() => loadUserSettings());
  const [snapshot, setSnapshot] = useState<WidgetSnapshot | null>(() => loadWidgetSnapshot());

  useEffect(() => {
    saveUserSettings(settings);
  }, [settings]);

  useEffect(() => {
    if (snapshot) saveWidgetSnapshot(snapshot);
  }, [snapshot]);

  const setQuickOrderNominal = useCallback((nominal: number) => {
    setSettings((prev) => ({ ...prev, quickOrderNominal: nominal }));
  }, []);

  const setPlatform = useCallback((p: string) => {
    setSettings((prev) => ({ ...prev, platform: p }));
  }, []);

  const recordQuickOrder = useCallback(
    (nominal?: number, lat?: number, lng?: number, namaLokasi?: string, wilayah?: string) => {
      const amount = nominal ?? settings.quickOrderNominal;
      const base = snapshot || {
        todayNet: 0,
        target: 0,
        platform: settings.platform,
        platformName: settings.platform,
        quickAmount: amount,
        trips: 0,
        remaining: 0,
        progressPct: 0,
      };

      const newSnap: WidgetSnapshot = {
        ...base,
        todayNet: base.todayNet + amount,
        trips: base.trips + 1,
        quickAmount: amount,
        remaining: Math.max(0, base.target - (base.todayNet + amount)),
        progressPct:
          base.target > 0
            ? Math.min(150, Math.round(((base.todayNet + amount) * 100) / base.target))
            : 0,
      };

      setSnapshot(newSnap);

      // Sinkronisasi ke widget Android native.
      if (typeof (window as any).OjolNative?.updateWidget === 'function') {
        try {
          (window as any).OjolNative.updateWidget(JSON.stringify(newSnap));
        } catch {
          /* abaikan */
        }
      }

      return { amount, newSnap, lat, lng, namaLokasi, wilayah };
    },
    [settings, snapshot]
  );

  return {
    settings,
    snapshot,
    setQuickOrderNominal,
    setPlatform,
    recordQuickOrder,
    formatRupiah,
  };
}
