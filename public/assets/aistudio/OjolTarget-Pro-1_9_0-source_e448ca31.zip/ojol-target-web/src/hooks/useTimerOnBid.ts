import { useState, useEffect, useCallback } from 'react';
import { loadTimerOnBid, saveTimerOnBid } from '@/lib/storage';
import { TimerOnBidState } from '@/types';

export function useTimerOnBid() {
  const [state, setState] = useState<TimerOnBidState>(() => loadTimerOnBid());
  const [isResetPending, setIsResetPending] = useState(false);

  // Load dari storage saat mount
  useEffect(() => {
    setState(loadTimerOnBid());
  }, []);

  // Simpan ke storage saat berubah
  useEffect(() => {
    saveTimerOnBid(state);
  }, [state]);

  // Jika running, update elapsed setiap detik
  useEffect(() => {
    if (!state.isRunning || !state.startTime) return;
    const id = setInterval(() => {
      setState((prev) => {
        if (!prev.isRunning || !prev.startTime) return prev;
        const now = Date.now();
        const sessionSeconds = Math.floor((now - prev.startTime) / 1000);
        const total = prev.elapsedSeconds + sessionSeconds;
        return { ...prev, totalSeconds: total };
      });
    }, 1000);
    return () => clearInterval(id);
  }, [state.isRunning, state.startTime, state.elapsedSeconds]);

  const start = useCallback(() => {
    setState((prev) => ({
      ...prev,
      isRunning: true,
      startTime: Date.now(),
    }));
  }, []);

  const pause = useCallback(() => {
    setState((prev) => {
      if (!prev.isRunning || !prev.startTime) return prev;
      const now = Date.now();
      const sessionSeconds = Math.floor((now - prev.startTime) / 1000);
      return {
        ...prev,
        isRunning: false,
        elapsedSeconds: prev.elapsedSeconds + sessionSeconds,
        startTime: null,
      };
    });
  }, []);

  // Reset: waktu sesi ini kembali ke 0, tapi elapsed (akumulasi) tetap disimpan
  const reset = useCallback(() => {
    setState((prev) => ({
      ...prev,
      isRunning: false,
      startTime: null,
      elapsedSeconds: prev.elapsedSeconds, // akumulasi tetap
      totalSeconds: prev.elapsedSeconds,    // total = akumulasi (waktu sesi dihapus)
    }));
    setIsResetPending(true);
    setTimeout(() => setIsResetPending(false), 1500);
  }, []);

  // Selesai: sama seperti reset tapi dengan konfirmasi
  const selesai = useCallback(() => {
    setState((prev) => ({
      ...prev,
      isRunning: false,
      startTime: null,
      elapsedSeconds: prev.elapsedSeconds,
      totalSeconds: prev.elapsedSeconds,
    }));
  }, []);

  const formatTime = (totalSeconds: number): string => {
    const h = Math.floor(totalSeconds / 3600);
    const m = Math.floor((totalSeconds % 3600) / 60);
    const s = totalSeconds % 60;
    return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const jamOnBid = state.totalSeconds / 3600;
  const pctTarget = Math.min(100, Math.round((jamOnBid / state.targetJam) * 100));

  return {
    state,
    isRunning: state.isRunning,
    elapsedSeconds: state.totalSeconds,
    formatTime: formatTime(state.totalSeconds),
    jamOnBid,
    pctTarget,
    start,
    pause,
    reset,
    selesai,
    isResetPending,
  };
}
