import React, { useState } from 'react';
import { loadServices, saveServices } from '@/lib/storage';
import { ServiceRecord, ServiceType, SERVICE_INTERVALS } from '@/types';
import { formatRupiah, formatKM } from '@/lib/nominatim';
import { hitungSisaKM } from '@/lib/service';
import { OnboardingData } from '@/types';

interface RiwayatServisProps {
  onboarding: OnboardingData;
}

export function RiwayatServis({ onboarding }: RiwayatServisProps) {
  const [services, setServices] = useState<ServiceRecord[]>(() => loadServices());
  const [editing, setEditing] = useState<{ id: string; currentKM: number } | null>(null);

  const hitungUntukTampilan = (s: ServiceRecord) => {
    const interval = SERVICE_INTERVALS[s.type];
    const targetKM = s.kmAtServis + interval;
    const sisa = Math.max(0, targetKM - onboarding.currentKM);
    const pct = Math.min(100, Math.round(((onboarding.currentKM - s.kmAtServis) / interval) * 100));
    return { sisa, targetKM, pct };
  };

  const tambahServis = (type: ServiceType) => {
    const km = window.prompt(`Masukkan KM kendaraan saat ini untuk servis ${type}:`, onboarding.currentKM.toString());
    if (km === null) return;
    const currentKM = parseInt(km) || onboarding.currentKM;
    const record: ServiceRecord = {
      id: crypto.randomUUID(),
      type,
      kmAtServis: currentKM, // reset: dimulai dari KM saat ini
      currentKM,
      kmSisa: SERVICE_INTERVALS[type],
      targetKM: currentKM + SERVICE_INTERVALS[type],
      catatan: '',
      tanggal: new Date().toISOString(),
      createdAt: Date.now(),
    };
    setServices((prev) => {
      const next = [...prev, record];
      saveServices(next);
      return next;
    });
  };

  const hapusServis = (id: string) => {
    if (!window.confirm('Hapus data servis ini?')) return;
    setServices((prev) => {
      const next = prev.filter((s) => s.id !== id);
      saveServices(next);
      return next;
    });
  };

  // Tampilkan hanya jenis servis yang ada (sinkronisasi)
  const jenisTersedia = [...new Set(services.map((s) => s.type))];

  return (
    <div>
      <div className="card-header">
        <span className="card-title">🔧 Riwayat Servis</span>
      </div>

      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 12 }}>
        {(['Oli', 'Mesin', 'Kopling', 'Rem', 'Aki', 'Filter'] as ServiceType[]).map((t) => (
          <button
            key={t}
            className={`btn btn-outline ${jenisTersedia.includes(t) ? 'btn-primary' : ''}`}
            onClick={() => tambahServis(t)}
            style={{ fontSize: '12px', padding: '6px 10px' }}
          >
            + {t}
          </button>
        ))}
      </div>

      {services.length === 0 ? (
        <div className="text-slate text-center py-12">
          Belum ada data servis. Tekan tombol jenis servis di atas untuk menambahkan.
        </div>
      ) : (
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Jenis</th>
                <th>KM Saat Servis</th>
                <th>KM Sekarang</th>
                <th>Sisa KM</th>
                <th>Target KM</th>
                <th>Tanggal</th>
                <th>Aksi</th>
              </tr>
            </thead>
            <tbody>
              {services
                .slice()
                .sort((a, b) => b.createdAt - a.createdAt)
                .map((s) => {
                  const { sisa, targetKM, pct } = hitungUntukTampilan(s);
                  return (
                    <tr key={s.id}>
                      <td>
                        <span className="badge badge-green">{s.type}</span>
                      </td>
                      <td>{formatKM(s.kmAtServis)}</td>
                      <td>{formatKM(s.currentKM)}</td>
                      <td>
                        <span className={sisa <= 0 ? 'text-red' : 'text-yellow'}>
                          {sisa.toLocaleString('id-ID')} KM
                        </span>
                      </td>
                      <td>{formatKM(targetKM)}</td>
                      <td>{new Date(s.tanggal).toLocaleDateString('id-ID')}</td>
                      <td>
                        <button className="btn btn-danger" onClick={() => hapusServis(s.id)} style={{ fontSize: '11px', padding: '4px 8px' }}>
                          Hapus
                        </button>
                      </td>
                    </tr>
                  );
                })}
            </tbody>
          </table>
        </div>
      )}

      <div className="card" style={{ marginTop: 16 }}>
        <div className="card-header">
          <span className="card-title">Sinkronisasi KM</span>
        </div>
        <div className="card-subtitle">
          KM kendaraan saat ini: <span className="font-mono text-yellow">{formatKM(onboarding.currentKM)}</span>
        </div>
        <div className="card-subtitle text-slate">
          Setiap servis baru akan mereset hitungan KM-nya dari 0 untuk kategori servis tersebut.
          Jenis servis yang telah dicatat akan muncul di atas sesuai data yang tersimpan.
        </div>
      </div>
    </div>
  );
}
