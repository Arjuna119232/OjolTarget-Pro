import { Page } from '@/types';

interface NavBarProps {
  page: Page;
  onPageChange: (p: Page) => void;
}

const ITEMS: Array<{ id: Page; label: string; icon: string }> = [
  { id: 'cockpit', label: 'Cockpit', icon: '🏁' },
  { id: 'catat-order', label: 'Order', icon: '📝' },
  { id: 'strategi', label: 'Strategi', icon: '🗺️' },
  { id: 'level-grab', label: 'Level Grab', icon: '🏆' },
  { id: 'riwayat-servis', label: 'Servis', icon: '🔧' },
  { id: 'pengaturan', label: 'Pengaturan', icon: '⚙️' },
];

export function NavBar({ page, onPageChange }: NavBarProps) {
  return (
    <nav className="nav-bar">
      {ITEMS.map((item) => (
        <button
          key={item.id}
          className={`nav-item ${page === item.id ? 'active' : ''}`}
          onClick={() => onPageChange(item.id)}
          aria-label={item.label}
        >
          <span className="icon">{item.icon}</span>
          <span>{item.label}</span>
        </button>
      ))}
    </nav>
  );
}
