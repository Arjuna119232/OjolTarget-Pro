import React, { useState } from 'react';
import { loadServices, loadTimerOnBid, loadUserSettings, loadSpotData } from '@/lib/storage';
import { formatRupiah } from '@/lib/nominatim';
import { servisTerdekat } from '@/lib/service';
import { OnboardingData } from '@/types';
import { TimerOnBid } from './TimerOnBid';
import { useSpotData } from '@/hooks/useSpotData';
import { useQuickOrder } from '@/hooks/useQuickOrder';
import { getCurrentPositionOnce } from '@/lib/geo';

interface CockpitProps {
  onboarding: OnboardingData;
}

export function Cockpit({ onboarding }: CockpitProps) {
  const [services] = useState<any[]>(() => loadServices());
  const [timer] = useState<any>(() => loadTimerOnBid());
  const [userSettings] = useState<any>(() => loadUserSettings());
  const [spots] = useState<any[]>(() => loadSpotData());
  const [toast, setToast] = useState<string | null>(null);

  const { addSpot, loading } = useSpotData();
  const { recordQuickOrder, settings } = useQuickOrder();

  const { servis: servisTerdekatData, sisaKM } = servisTerdekat(
    services,
    onboarding.currentKM
  );

  const totalOrder = spots.reduce((acc, s) => acc + (s.nominal || 0), 0);

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 2500);
  };

  const tandaiSpot = async () => {
    try {
      const { lat, lng } = await getCurrentPositionOnce();
      const spot = await addSpot(lat, lng);
      showToast(`📍 Spot ditandai: ${spot.wilayah} (${spot.namaLokasi})`);
    } catch {
      showToast('GPS tidak tersedia. Gunakan input manual di halaman Order.');
    }
  };

  const catatOrder = () => {
    recordQuickOrder();
    showToast(`💰 Order ${formatRupiah(settings.quickOrderNominal)} dicatat`);
  };

  return (
    <div>
      <div className="card-header">
        <span className="card-title">Cockpit Driver</span>
        <span className="badge badge-green">Online</span>
      </div>

      {/* Quick stats */}
      <div className="grid-4">
        <div className="card">
          <div className="card-subtitle">Total Order</div>
          <div className="font-mono text-green" style={{ fontSize: '20px' }}>
            {spots.length}
          </div>
          <div className="card-subtitle">{formatRupiah(totalOrder)}</div>
        </div>
        <div className="card">
          <div className="card-subtitle">Jam On-Bid</div>
          <div className="font-mono text-yellow" style={{ fontSize: '20px' }}>
            {(timer?.totalSeconds / 3600).toFixed(1)}
          </div>
          <div className="card-subtitle">target 250 jam</div>
        </div>
        <div className="card">
          <div className="card-subtitle">KM Saat Ini</div>
          <div className="font-mono text-yellow" style={{ fontSize: '20px' }}>
            {onboarding.currentKM.toLocaleString('id-ID')}
          </div>
          <div className="card-subtitle">{onboarding.nomorKendaraan}</div>
        </div>
        <div className="card">
          <div className="card-subtitle">Platform</div>
          <div className="font-mono text-green" style={{ fontSize: '20px' }}>
            {onboarding.platform}
          </div>
          <div className="card-subtitle">{onboarding.nama}</div>
        </div>
      </div>

      {/* Timer On-Bid */}
      <div style={{ marginTop: 16 }}>
        <TimerOnBid targetJam={250} />
      </div>

      {/* Servis Terdekat */}
      <div className="card" style={{ marginTop: 16 }}>
        <div className="card-header">
          <span className="card-title">🔧 Servis Terdekat</span>
        </div>
        {servisTerdekatData ? (
          <div className="grid-3">
            <div>
              <div className="card-subtitle">Jenis</div>
              <div className="font-mono">{servisTerdekatData.type}</div>
            </div>
            <div>
              <div className="card-subtitle">Sisa KM</div>
              <div className="font-mono text-red" style={{ fontSize: '20px' }}>
                {sisaKM.toLocaleString('id-ID')} KM
              </div>
            </div>
            <div>
              <div className="card-subtitle">Target KM</div>
              <div className="font-mono">
                {servisTerdekatData.targetKM.toLocaleString('id-ID')}
              </div>
            </div>
          </div>
        ) : (
          <div className="text-slate text-center" style={{ padding: '24px 0' }}>
            Belum ada data servis. Input data servis pada halaman Riwayat Servis.
          </div>
        )}
      </div>

      {/* Aksi cepat */}
      <div className="grid-2" style={{ marginTop: 16 }}>
        <button className="btn btn-primary" onClick={tandaiSpot} disabled={loading} style={{ padding: 16 }}>
          {loading ? 'Mengambil GPS...' : '📍 Tandai Spot'}
        </button>
        <button className="btn btn-warning" onClick={catatOrder} style={{ padding: 16 }}>
          💰 Catat {formatRupiah(userSettings?.quickOrderNominal || 10200)}
        </button>
      </div>

      {toast && (
        <div
          className="card"
          style={{
            position: 'fixed',
            bottom: 80,
            left: 16,
            right: 16,
            textAlign: 'center',
            background: '#10b981',
            color: '#fff',
            zIndex: 200,
          }}
        >
          {toast}
        </div>
      )}
    </div>
  );
}
