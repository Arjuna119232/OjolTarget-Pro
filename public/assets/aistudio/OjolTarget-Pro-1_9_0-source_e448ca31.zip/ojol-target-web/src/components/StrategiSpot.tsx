import React, { useState, useMemo } from 'react';
import { loadSpotData } from '@/lib/storage';
import { loadOnboarding } from '@/lib/storage';
import { formatRupiah } from '@/lib/nominatim';
import { SpotData } from '@/types';
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { exportLaporanStrategiPDF } from '@/lib/pdf';

const COLORS = ['#10b981', '#3b82f6', '#f59e0b', '#ef4444', '#8b5cf6', '#06b6d4'];

export function StrategiSpot() {
  const [spots] = useState<SpotData[]>(() => loadSpotData());
  const [onboarding] = useState<any>(() => loadOnboarding());
  const [filter, setFilter] = useState<'harian' | 'mingguan' | 'bulanan'>('bulanan');

  const now = new Date();
  const startOfPeriod = filter === 'harian'
    ? new Date(now.getFullYear(), now.getMonth(), now.getDate())
    : filter === 'mingguan'
    ? new Date(now.getFullYear(), now.getMonth(), now.getDate() - 7)
    : new Date(now.getFullYear(), now.getMonth(), 1);

  const filtered = useMemo(() => spots.filter((s) => new Date(s.timestamp) >= startOfPeriod), [spots, startOfPeriod]);

  // Wilayah stats
  const wilayahStats = useMemo(() => {
    const map: Record<string, { count: number; total: number; spots: string[] }> = {};
    filtered.forEach((s) => {
      if (!map[s.wilayah]) map[s.wilayah] = { count: 0, total: 0, spots: [] };
      map[s.wilayah].count++;
      map[s.wilayah].total += s.nominal || 0;
      if (s.namaLokasi && !map[s.wilayah].spots.includes(s.namaLokasi)) {
        map[s.wilayah].spots.push(s.namaLokasi);
      }
    });
    return map;
  }, [filtered]);

  // Jam gacor stats
  const jamStats = useMemo(() => {
    const map: Record<string, number> = {};
    filtered.forEach((s) => {
      map[s.jamGacor] = (map[s.jamGacor] || 0) + 1;
    });
    return map;
  }, [filtered]);

  const totalOrder = filtered.length;
  const totalNominal = filtered.reduce((acc, s) => acc + (s.nominal || 0), 0);
  const topWilayah = Object.entries(wilayahStats).sort((a, b) => b[1].count - a[1].count)[0];
  const topJam = Object.entries(jamStats).sort((a, b) => b[1] - a[1])[0];

  const wilayahData = Object.entries(wilayahStats).map(([k, v]) => ({ name: k, value: v.count, total: v.total }));
  const jamData = Object.entries(jamStats).map(([name, value]) => ({ name, value }));

  const handlePDF = () => {
    const detail = filtered.map((s) => ({
      wilayah: s.wilayah,
      jam: s.jamGacor,
      jumlah: 1,
      spot: s.namaLokasi || '-',
    }));
    exportLaporanStrategiPDF({
      namaDriver: onboarding?.nama || 'Driver',
      periode: filter === 'bulanan' ? `${now.toLocaleString('id-ID', { month: 'long' })} ${now.getFullYear()}` : 'Harian',
      totalOrder,
      wilayahFavorit: topWilayah ? topWilayah[0] : '-',
      jamTersibuk: topJam ? topJam[0] : '-',
      detail,
    });
  };

  return (
    <div>
      <div className="card-header">
        <span className="card-title">🗺️ Strategi Spot & Waktu</span>
      </div>

      <div style={{ display: 'flex', gap: 8, marginBottom: 12 }}>
        {(['harian', 'mingguan', 'bulanan'] as const).map((f) => (
          <button
            key={f}
            className={`btn btn-outline ${filter === f ? 'btn-primary' : ''}`}
            onClick={() => setFilter(f)}
            style={{ fontSize: '12px', padding: '6px 12px' }}
          >
            {f === 'harian' ? 'Harian' : f === 'mingguan' ? 'Mingguan' : 'Bulanan'}
          </button>
        ))}
        <button className="btn btn-secondary" onClick={handlePDF} style={{ marginLeft: 'auto', fontSize: '12px', padding: '6px 12px' }}>
          📄 Ekspor PDF
        </button>
      </div>

      <div className="grid-3">
        <div className="card">
          <div className="card-subtitle">Total Order</div>
          <div className="font-mono text-green" style={{ fontSize: '24px' }}>{totalOrder}</div>
          <div className="card-subtitle">{formatRupiah(totalNominal)}</div>
        </div>
        <div className="card">
          <div className="card-subtitle">Wilayah Favorit</div>
          <div className="font-mono text-yellow" style={{ fontSize: '20px' }}>{topWilayah ? topWilayah[0] : '-'}</div>
          <div className="card-subtitle">{topWilayah ? topWilayah[1].count + ' order' : '-'}</div>
        </div>
        <div className="card">
          <div className="card-subtitle">Jam Tersibuk</div>
          <div className="font-mono text-yellow" style={{ fontSize: '20px' }}>{topJam ? topJam[0] : '-'}</div>
          <div className="card-subtitle">{topJam ? topJam[1] + ' order' : '-'}</div>
        </div>
      </div>

      <div className="grid-2" style={{ gap: 16 }}>
        {/* Donut chart - wilayah */}
        <div className="card" style={{ minHeight: 300 }}>
          <div className="card-header">
            <span className="card-title">Distribusi per Wilayah</span>
          </div>
          <div style={{ height: 240 }}>
            {wilayahData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    dataKey="value"
                    data={wilayahData}
                    cx="50%"
                    cy="50%"
                    innerRadius={80}
                    outerRadius={100}
                    label={true}
                  >
                    {wilayahData.map((_, i) => (
                      <Cell key={`cell-${i}`} fill={COLORS[i % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="spot-map-placeholder">Belum ada data wilayah</div>
            )}
          </div>
        </div>

        {/* Bar chart - jam gacor */}
        <div className="card" style={{ minHeight: 300 }}>
          <div className="card-header">
            <span className="card-title">Jam Gacor (Tersibuk)</span>
          </div>
          <div style={{ height: 240 }}>
            {jamData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={jamData}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="value" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="spot-map-placeholder">Belum ada data jam</div>
            )}
          </div>
        </div>
      </div>

      {/* Tabel detail per wilayah */}
      <div className="card" style={{ marginTop: 16 }}>
        <div className="card-header">
          <span className="card-title">Detail per Wilayah</span>
        </div>
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Wilayah</th>
                <th>Jumlah Order</th>
                <th>Total Nominal</th>
                <th>Top Spot</th>
              </tr>
            </thead>
            <tbody>
              {Object.entries(wilayahStats).map(([wilayah, data]) => (
                <tr key={wilayah}>
                  <td>{wilayah}</td>
                  <td>{data.count}</td>
                  <td>{formatRupiah(data.total)}</td>
                  <td>{data.spots.slice(0, 3).join(', ') || '-'}</td>
                </tr>
              ))}
              {!Object.entries(wilayahStats).length && (
                <tr><td colSpan={4} className="text-slate text-center py-4">Belum ada data spot</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      <div className="card-subtitle text-slate text-center mt-2">
        © OpenStreetMap contributors — Data disimpan secara lokal di perangkat
      </div>
    </div>
  );
}
