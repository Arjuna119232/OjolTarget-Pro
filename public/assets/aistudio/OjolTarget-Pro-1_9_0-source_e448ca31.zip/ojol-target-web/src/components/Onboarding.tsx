import React, { useState } from 'react';
import { ServiceType, OnboardingData } from '@/types';
import { SERVICE_INTERVALS } from '@/types';

interface OnboardingProps {
  onSelesai: (data: OnboardingData) => void;
}

const SERVICES: ServiceType[] = ['Oli', 'Mesin', 'Kopling', 'Rem', 'Aki', 'Filter'];
const PLATFORMS = ['Grab', 'Gojek', 'Maxim', 'InDriver', 'Lainnya'];

export function Onboarding({ onSelesai }: OnboardingProps) {
  const [step, setStep] = useState(0);
  const [form, setForm] = useState({
    nama: '',
    platform: '',
    nomorKendaraan: '',
    currentKM: '',
    services: [] as ServiceType[],
  });

  const next = () => {
    if (step === 0 && (!form.nama || !form.platform || !form.nomorKendaraan)) return;
    if (step === 1 && (!form.currentKM || form.services.length === 0)) return;
    setStep(step + 1);
  };
  const prev = () => setStep(step - 1);

  const selesai = () => {
    const data: OnboardingData = {
      nama: form.nama,
      platform: form.platform,
      nomorKendaraan: form.nomorKendaraan,
      currentKM: parseInt(form.currentKM) || 0,
      services: form.services,
      completed: true,
    };
    onSelesai(data);
  };

  if (step === 0) return <LangkahAwal />;
  if (step === 1) return <LangkahServis form={form} />;
  return <SelesaiOnboarding form={form} onSelesai={selesai} />;

  function LangkahAwal() {
    return (
      <div className="card">
        <div className="card-header">
          <span className="card-title">Selamat Datang di OjolTarget Pro</span>
        </div>
        <div className="step-indicator">
          <div className="step active"></div>
          <div className="step"></div>
        </div>
        <div className="grid-2">
          <div className="form-group">
            <label className="form-label">Nama Lengkap</label>
            <input
              value={form.nama}
              onChange={(e) => setForm({ ...form, nama: e.target.value })}
              placeholder="Contoh: Budi Santoso"
            />
          </div>
          <div className="form-group">
            <label className="form-label">Platform Utama</label>
            <select
              value={form.platform}
              onChange={(e) => setForm({ ...form, platform: e.target.value })}
            >
              <option value="">Pilih platform</option>
              {PLATFORMS.map((p) => (
                <option key={p} value={p}>{p}</option>
              ))}
            </select>
          </div>
        </div>
        <div className="form-group">
          <label className="form-label">Nomor Kendaraan (plat / ID)</label>
          <input
            value={form.nomorKendaraan}
            onChange={(e) => setForm({ ...form, nomorKendaraan: e.target.value })}
            placeholder="Contoh: B 1234 XYZ"
          />
        </div>
        <div className="card-subtitle text-slate text-center mt-4">
          Langkah berikutnya: pilih jenis servis yang diiklani
        </div>
        <button
          className="btn btn-primary"
          onClick={next}
          disabled={!form.nama || !form.platform || !form.nomorKendaraan}
          style={{ width: '100%', marginTop: 12 }}
        >
          Lanjutkan
        </button>
      </div>
    );
  }

  function LangkahServis({ form }: { form: any }) {
    return (
      <div className="card">
        <div className="card-header">
          <span className="card-title">Pilih Jenis Servis</span>
          <span className="card-subtitle">Centang semua yang berlaku</span>
        </div>
        <div className="step-indicator">
          <div className="step completed"></div>
          <div className="step active"></div>
        </div>
        <div className="grid-3" style={{ marginBottom: 16 }}>
          {SERVICES.map((t) => (
            <div key={t} className="checkbox-group">
              <input
                type="checkbox"
                checked={form.services.includes(t)}
                onChange={(e) => {
                  const arr = e.target.checked
                    ? [...form.services, t]
                    : form.services.filter((x: ServiceType) => x !== t);
                  setForm({ ...form, services: arr });
                }}
              />
              <label>
                {t} ({SERVICE_INTERVALS[t]} KM)
              </label>
            </div>
          ))}
        </div>
        <div className="form-group">
          <label className="form-label">KM Kendaraan Saat Ini</label>
          <input
            type="number"
            value={form.currentKM}
            onChange={(e) => setForm({ ...form, currentKM: e.target.value })}
            placeholder="Contoh: 45000"
          />
        </div>
        <div className="card-subtitle text-slate text-center">
          Hitungan servis akan dimulai dari KM ini (reset 0 untuk tiap kategori)
        </div>
        <div style={{ display: 'flex', gap: 8, justifyContent: 'space-between' }}>
          <button className="btn btn-secondary" onClick={prev}>Kembali</button>
          <button
            className="btn btn-primary"
            onClick={next}
            disabled={!form.currentKM || form.services.length === 0}
          >
            Selesai
          </button>
        </div>
      </div>
    );
  }

  function SelesaiOnboarding({ form, onSelesai }: { form: any; onSelesai: () => void }) {
    return (
      <div className="card">
        <div className="card-header">
          <span className="card-title">Onboarding Selesai</span>
        </div>
        <div className="grid-2">
          <div>
            <div className="card-subtitle">Nama</div>
            <div>{form.nama}</div>
          </div>
          <div>
            <div className="card-subtitle">Platform</div>
            <div>{form.platform}</div>
          </div>
          <div>
            <div className="card-subtitle">Kendaraan</div>
            <div>{form.nomorKendaraan}</div>
          </div>
          <div>
            <div className="card-subtitle">KM Saat Ini</div>
            <div>{form.currentKM}</div>
          </div>
        </div>
        <div className="card-subtitle">
          Jenis servis: {form.services.join(', ')}
        </div>
        <div className="card-subtitle text-green text-center mt-3">
          Data servis akan dihitung dari KM {form.currentKM} (setiap kategori dimulai dari 0)
        </div>
        <button
          className="btn btn-primary"
          onClick={onSelesai}
          style={{ width: '100%', marginTop: 16 }}
        >
          Masuk ke Aplikasi
        </button>
      </div>
    );
  }
}
