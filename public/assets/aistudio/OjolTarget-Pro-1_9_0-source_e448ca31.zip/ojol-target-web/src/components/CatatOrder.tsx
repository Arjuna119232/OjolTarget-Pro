import React, { useState } from 'react';
import { OnboardingData } from '@/types';
import { useSpotData } from '@/hooks/useSpotData';
import { useQuickOrder } from '@/hooks/useQuickOrder';
import { formatRupiah } from '@/lib/nominatim';
import { getCurrentPositionOnce } from '@/lib/geo';

interface CatatOrderProps {
  onboarding: OnboardingData;
}

export function CatatOrder(_props: CatatOrderProps) {
  const [manualLat, setManualLat] = useState('');
  const [manualLng, setManualLng] = useState('');
  const [manualNama, setManualNama] = useState('');
  const [manualWilayah, setManualWilayah] = useState('');
  const [lastResult, setLastResult] = useState<{ amount: number; nama: string; wilayah: string } | null>(null);

  const { addSpot, loading } = useSpotData();
  const { recordQuickOrder, settings, setQuickOrderNominal } = useQuickOrder();

  const handleGPS = async () => {
    try {
      const { lat, lng } = await getCurrentPositionOnce();
      const spot = await addSpot(lat, lng);
      setLastResult({ amount: settings.quickOrderNominal, nama: spot.namaLokasi, wilayah: spot.wilayah });
    } catch {
      alert('GPS tidak tersedia. Silakan input manual.');
    }
  };

  const handleManual = async () => {
    const lat = parseFloat(manualLat);
    const lng = parseFloat(manualLng);
    if (isNaN(lat) || isNaN(lng)) return alert('Koordinat tidak valid');
    await addSpot(lat, lng, manualNama, manualWilayah || undefined);
    setLastResult({ amount: settings.quickOrderNominal, nama: manualNama || 'Manual', wilayah: manualWilayah || 'Auto' });
  };

  const handleDapatOrder = async () => {
    try {
      const { lat, lng } = await getCurrentPositionOnce();
      const spot = await addSpot(lat, lng);
      recordQuickOrder(settings.quickOrderNominal, lat, lng, 'Dapat Order - GPS', spot.wilayah);
      setLastResult({ amount: settings.quickOrderNominal, nama: 'Dapat Order', wilayah: spot.wilayah });
    } catch {
      alert('GPS tidak tersedia');
    }
  };

  const handleTurun = async () => {
    try {
      const { lat, lng } = await getCurrentPositionOnce();
      const spot = await addSpot(lat, lng);
      recordQuickOrder(settings.quickOrderNominal, lat, lng, 'Turun - GPS', spot.wilayah);
      setLastResult({ amount: settings.quickOrderNominal, nama: 'Turun', wilayah: spot.wilayah });
    } catch {
      alert('GPS tidak tersedia');
    }
  };

  return (
    <div>
      <div className="card-header">
        <span className="card-title">Catat Order</span>
      </div>

      {/* Satu klik */}
      <div className="card">
        <div className="card-header">
          <span className="card-title">🚀 Catat Order Satu Klik</span>
        </div>
        <div className="form-group">
          <label className="form-label">Nominal Default (Rp)</label>
          <input
            type="number"
            value={settings.quickOrderNominal}
            onChange={(e) => setQuickOrderNominal(parseInt(e.target.value) || 10200)}
          />
          <div className="card-subtitle text-slate">
            Ubah di Pengaturan jika ingin nominal berbeda
          </div>
        </div>
        <div style={{ display: 'flex', gap: 8, flexDirection: 'column' }}>
          <button
            className="btn btn-warning"
            onClick={() => {
              recordQuickOrder();
              setLastResult({ amount: settings.quickOrderNominal, nama: 'Satu Klik', wilayah: '-' });
            }}
            style={{ width: '100%', padding: 16, fontSize: '18px' }}
          >
            💰 Catat {formatRupiah(settings.quickOrderNominal)}
          </button>
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="btn btn-primary" onClick={handleDapatOrder} disabled={loading} style={{ flex: 1 }}>
              Dapat Order
            </button>
            <button className="btn btn-primary" onClick={handleTurun} disabled={loading} style={{ flex: 1 }}>
              Turun
            </button>
          </div>
        </div>
        {lastResult && (
          <div className="card-subtitle text-green text-center" style={{ marginTop: 12 }}>
            Tercatat: {formatRupiah(lastResult.amount)} • {lastResult.nama} • {lastResult.wilayah}
          </div>
        )}
      </div>

      {/* GPS Tandai Spot */}
      <div className="card" style={{ marginTop: 16 }}>
        <div className="card-header">
          <span className="card-title">📍 Tandai Spot Manual</span>
        </div>
        <button className="btn btn-primary" onClick={handleGPS} disabled={loading} style={{ width: '100%', marginBottom: 12 }}>
          {loading ? 'Mengambil GPS...' : 'Ambil GPS & Tandai Spot'}
        </button>
        <div className="grid-2">
          <div className="form-group">
            <label className="form-label">Latitude</label>
            <input value={manualLat} onChange={(e) => setManualLat(e.target.value)} placeholder="-6.2088" />
          </div>
          <div className="form-group">
            <label className="form-label">Longitude</label>
            <input value={manualLng} onChange={(e) => setManualLng(e.target.value)} placeholder="106.8456" />
          </div>
        </div>
        <div className="form-group">
          <label className="form-label">Nama Spot / Jalan (opsional)</label>
          <input value={manualNama} onChange={(e) => setManualNama(e.target.value)} placeholder="Jl. Sudirman" />
        </div>
        <div className="form-group">
          <label className="form-label">Wilayah</label>
          <select value={manualWilayah} onChange={(e) => setManualWilayah(e.target.value)}>
            <option value="">Auto deteksi</option>
            <option value="Jaksel">Jaksel</option>
            <option value="Jakbar">Jakbar</option>
            <option value="Jakpus">Jakpus</option>
            <option value="Jaktim">Jaktim</option>
            <option value="Jakut">Jakut</option>
            <option value="Luar Jakarta">Luar Jakarta</option>
          </select>
        </div>
        <button className="btn btn-secondary" onClick={handleManual} disabled={loading} style={{ width: '100%' }}>
          Simpan Spot Manual
        </button>
      </div>

      <div className="card-subtitle text-slate text-center" style={{ marginTop: 16 }}>
        Setiap penekanan tombol di atas akan mengambil GPS dan menyimpan spot untuk fitur Spot Gacor.
      </div>
    </div>
  );
}
