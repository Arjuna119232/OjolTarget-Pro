import React, { useState } from 'react';
import { saveUserSettings, loadUserSettings } from '@/lib/storage';
import { UserSettings } from '@/types';
import { formatRupiah } from '@/lib/nominatim';
import { OnboardingData } from '@/types';

interface PengaturanProps {
  onboarding: OnboardingData;
}

export function Pengaturan({ onboarding }: PengaturanProps) {
  const [settings, setSettings] = useState<UserSettings>(() => loadUserSettings());

  const simpan = () => {
    setSettings((prev) => {
      const next = { ...prev, platform: onboarding.platform };
      saveUserSettings(next);
      return next;
    });
    window.alert('Pengaturan tersimpan');
  };

  return (
    <div>
      <div className="card-header">
        <span className="card-title">⚙️ Pengaturan</span>
      </div>

      <div className="card">
        <div className="form-group">
          <label className="form-label">Nominal Default Catat Order 1 Klik (Rp)</label>
          <input
            type="number"
            value={settings.quickOrderNominal}
            onChange={(e) => setSettings((prev) => ({ ...prev, quickOrderNominal: parseInt(e.target.value) || 10200 }))}
          />
          <div className="card-subtitle text-slate">
            Nominal ini akan digunakan saat menekan tombol "Catat Order Cepat"
          </div>
        </div>
        <div className="form-group">
          <label className="form-label">Platform Utama</label>
          <select
            value={settings.platform || onboarding.platform}
            onChange={(e) => setSettings((prev) => ({ ...prev, platform: e.target.value }))}
          >
            <option value="Grab">Grab</option>
            <option value="Gojek">Gojek</option>
            <option value="Maxim">Maxim</option>
            <option value="InDriver">InDriver</option>
            <option value="Lainnya">Lainnya</option>
          </select>
        </div>
        <div className="form-group">
          <label className="form-label">Nama Driver</label>
          <input
            value={onboarding.nama}
            readOnly
            className="bg-slate-900/50"
          />
        </div>
        <div className="form-group">
          <label className="form-label">Kendaraan</label>
          <input
            value={onboarding.nomorKendaraan}
            readOnly
            className="bg-slate-900/50"
          />
        </div>
        <button className="btn btn-primary" onClick={simpan} style={{ width: '100%', marginTop: 16 }}>
          Simpan Pengaturan
        </button>
      </div>

      <div className="card" style={{ marginTop: 16 }}>
        <div className="card-header">
          <span className="card-title">Tentang</span>
        </div>
        <div className="card-subtitle">OjolTarget Pro v1.9.0</div>
        <div className="card-subtitle">Package: com.ojoltarget.pro</div>
        <div className="card-subtitle">minSdk 24, targetSdk 35</div>
        <div className="card-subtitle text-slate mt-2">
          Fitur: Catat Order 1 Klik, Widget Sync, Spot Gacor (GPS + Nominatim), Level Grab (Grab), Riwayat Servis, Export PDF
        </div>
        <div className="card-subtitle text-slate mt-1">
          © 2026 OjolTarget Pro — Data disimpan secara lokal di perangkat
        </div>
      </div>
    </div>
  );
}
