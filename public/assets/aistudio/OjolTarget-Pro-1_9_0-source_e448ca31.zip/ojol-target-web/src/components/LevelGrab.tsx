import React, { useState } from 'react';
import { LEVEL_TARGETS, GrabLevel } from '@/types';
import { computeLevelProgress, getLevelIndicatorColor, getLevelColor, getProgressColor, hitungSisaHari } from '@/lib/level';

interface LevelGrabProps {}

export function LevelGrab() {
  const [level, setLevel] = useState<GrabLevel | null>(null);
  const [current, setCurrent] = useState({
    hariOnline: 0,
    jamOnline: 0,
    penyelesaian: 0,
    rating: 4.0,
    orderan: 0,
  });

  const progress = level ? computeLevelProgress(level, current) : null;
  const color = level && progress ? getLevelIndicatorColor(level, progress, current) : null;
  const sisaHari = hitungSisaHari();

  const kriteria = [
    { key: 'hariOnline', label: 'Hari Online', target: level ? LEVEL_TARGETS[level].hari : 0, unit: 'hari', value: current.hariOnline },
    { key: 'jamOnline', label: 'Jam Online', target: level ? LEVEL_TARGETS[level].jam : 0, unit: 'jam', value: current.jamOnline },
    { key: 'penyelesaian', label: 'Tingkat Penyelesaian', target: level ? LEVEL_TARGETS[level].penyelesaian : 0, unit: '%', value: current.penyelesaian },
    { key: 'rating', label: 'Rating', target: level ? LEVEL_TARGETS[level].rating : 0, unit: '', value: current.rating },
    { key: 'orderan', label: 'Jumlah Orderan', target: level ? LEVEL_TARGETS[level].orderan : 0, unit: 'order', value: current.orderan },
  ];

  return (
    <div>
      <div className="card-header">
        <span className="card-title">🏆 Level Grab (Jabodetabek)</span>
      </div>

      {/* Pilih Level */}
      <div className="card">
        <div className="card-header">
          <span className="card-title">Pilih Target Level</span>
        </div>
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
          {(['Pejuang', 'Kesatria', 'Jawara'] as const).map((lv) => {
            const t = LEVEL_TARGETS[lv];
            const isSelected = level === lv;
            return (
              <button
                key={lv}
                className={`btn ${isSelected ? 'btn-primary' : 'btn-secondary'}`}
                onClick={() => setLevel(lv)}
                style={{ flex: 1, minWidth: 110 }}
              >
                {lv}
                <div className="card-subtitle" style={{ fontSize: '10px', marginTop: 2, opacity: 0.8 }}>
                  {t.orderan} order • {t.jam} jam
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {!level ? null : (
        <>
          {/* Indikator warna */}
          <div className="card" style={{ marginTop: 12 }}>
            <div className="card-header">
              <span className="card-title">Indikator Level: {level}</span>
              <span className={`badge badge-${color || 'red'}`}>
                {color === 'merah' ? 'Belum Tercapai' : color === 'kuning' ? 'Dalam Proses' : color === 'hijau' ? 'Tercapai' : 'Pelangi'}
              </span>
            </div>
            <div className="card-subtitle text-center">
              Sisa hari bulan ini: <span className="font-mono text-yellow">{sisaHari}</span> hari
            </div>
            <div style={{ height: 10 }}></div>
            <div className="level-card" style={{ textAlign: 'center' }}>
              <div className="level-title" style={{ color: getLevelColor(level) }}>
                {level} - Target Bulanan
              </div>
              <div className="grid-5" style={{ marginTop: 16 }}>
                {kriteria.map((k) => {
                  const pct = k.target > 0 ? Math.min(100, Math.round((k.value / k.target) * 100)) : 0;
                  return (
                    <div key={k.key} className="card" style={{ padding: 8 }}>
                      <div className="card-subtitle" style={{ fontSize: '11px' }}>{k.label}</div>
                      <div style={{ fontSize: '10px', color: '#94a3b8', marginBottom: 4 }}>{k.value} / {k.target} {k.unit}</div>
                      <div className="progress-track">
                        <div className="progress-fill" style={{ width: `${pct}%`, background: getProgressColor(pct) }}></div>
                      </div>
                      <div style={{ fontSize: '11px', color: getProgressColor(pct), fontWeight: '700', marginTop: 4 }}>{pct}%</div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Input nilai aktual */}
          <div className="card" style={{ marginTop: 12 }}>
            <div className="card-header">
              <span className="card-title">Masukkan Realisasi Bulan Ini</span>
            </div>
            <div className="grid-3">
              {kriteria.map((k) => (
                <div key={k.key} className="form-group">
                  <label className="form-label">{k.label}</label>
                  <input
                    type="number"
                    value={current[k.key as keyof typeof current]}
                    onChange={(e) => {
                      const v = parseInt(e.target.value) || 0;
                      setCurrent((prev) => ({ ...prev, [k.key as keyof typeof current]: v }));
                    }}
                    placeholder={k.target?.toString()}
                  />
                </div>
              ))}
            </div>
          </div>
        </>
      )}

      {!level && (
        <div className="card text-slate text-center py-12">
          <div className="card-subtitle">Silakan pilih level target Grab di atas</div>
        </div>
      )}
    </div>
  );
}
