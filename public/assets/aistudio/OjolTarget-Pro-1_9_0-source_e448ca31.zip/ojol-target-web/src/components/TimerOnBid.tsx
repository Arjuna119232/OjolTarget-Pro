import React, { useState } from 'react';
import { useTimerOnBid } from '@/hooks/useTimerOnBid';

interface TimerOnBidProps {
  targetJam?: number;
}

export function TimerOnBid({ targetJam = 250 }: TimerOnBidProps) {
  const { isRunning, formatTime, jamOnBid, pctTarget, start, pause, selesai, reset, state } =
    useTimerOnBid();
  const [showSelesai, setShowSelesai] = useState(false);

  const konfirmasiSelesai = () => {
    // Reset timer ke 00:00:00, tapi akumulasi (elapsedSeconds) tetap disimpan
    selesai();
    setShowSelesai(false);
  };

  const handleReset = () => {
    reset();
  };

  return (
    <div className="card">
      <div className="card-header">
        <span className="card-title">⏱️ Timer On-Bid</span>
        <span className={`badge ${isRunning ? 'badge-green' : 'badge-yellow'}`}>
          {isRunning ? 'Berjalan' : 'Berhenti'}
        </span>
      </div>

      <div className="timer-display">{formatTime}</div>

      <div className="grid-2" style={{ marginBottom: 12 }}>
        <div style={{ textAlign: 'center' }}>
          <div className="card-subtitle">Total Jam On-Bid</div>
          <div className="font-mono text-green" style={{ fontSize: '20px' }}>
            {jamOnBid.toFixed(2)} jam
          </div>
        </div>
        <div style={{ textAlign: 'center' }}>
          <div className="card-subtitle">Target</div>
          <div className="font-mono text-yellow" style={{ fontSize: '20px' }}>
            {targetJam} jam
          </div>
        </div>
      </div>

      <div className="progress-track" style={{ marginBottom: 16 }}>
        <div
          className="progress-fill"
          style={{
            width: `${pctTarget}%`,
            background: pctTarget >= 100 ? '#22c55e' : '#10b981',
          }}
        ></div>
      </div>
      <div className="card-subtitle text-center" style={{ marginBottom: 12 }}>
        {pctTarget}% dari target {targetJam} jam
      </div>

      <div style={{ display: 'flex', gap: 8 }}>
        {!isRunning ? (
          <button className="btn btn-primary" onClick={start} style={{ flex: 1 }}>
            ▶ Mulai
          </button>
        ) : (
          <button className="btn btn-secondary" onClick={pause} style={{ flex: 1 }}>
            ⏸ Jeda
          </button>
        )}
        <button
          className="btn btn-danger"
          onClick={() => setShowSelesai(true)}
          style={{ flex: 1 }}
        >
          ⏹ Selesai
        </button>
        <button className="btn btn-secondary" onClick={handleReset} style={{ flex: 1 }}>
          ↺ Reset
        </button>
      </div>

      <div className="card-subtitle text-slate text-center" style={{ marginTop: 8, fontSize: '11px' }}>
        Saat "Selesai" ditekan, timer kembali ke 00:00:00 namun waktu yang sudah berjalan
        tetap diakumulasikan ke total Jam On-Bid.
      </div>

      {showSelesai && (
        <div className="modal-overlay" onClick={() => setShowSelesai(false)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <div className="modal-title">Selesaikan Sesi On-Bid?</div>
            <p className="card-subtitle">
              Timer akan direset ke <span className="font-mono text-green">00:00:00</span>.
              Waktu sesi ini (<span className="font-mono">{formatTime}</span>) akan ditambahkan
              ke total Jam On-Bid.
            </p>
            <div style={{ display: 'flex', gap: 8, marginTop: 16 }}>
              <button className="btn btn-secondary" onClick={() => setShowSelesai(false)} style={{ flex: 1 }}>
                Batal
              </button>
              <button className="btn btn-primary" onClick={konfirmasiSelesai} style={{ flex: 1 }}>
                Selesai & Reset
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="card-subtitle text-slate" style={{ fontSize: '10px', marginTop: 8 }}>
        Akumulasi tersimpan: {state.elapsedSeconds.toLocaleString('id-ID')} detik
      </div>
    </div>
  );
}
