import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './index.css';
import { installWidgetSync } from './lib/widgetSync';

// Hook sinkronisasi order/spot dari widget Android native.
installWidgetSync();

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
