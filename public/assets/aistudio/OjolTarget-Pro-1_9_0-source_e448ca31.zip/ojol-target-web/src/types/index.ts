export type ServiceType = 'Oli' | 'Mesin' | 'Kopling' | 'Rem' | 'Aki' | 'Filter';

export interface ServiceRecord {
  id: string;
  type: ServiceType;
  kmAtServis: number; // KM saat servis dilakukan
  currentKM: number;  // KM kendaraan saat input
  kmSisa: number;     // sisa KM hingga servis berikutnya
  targetKM: number;   // target KM servis berikutnya (kmAtServis + interval)
  catatan: string;
  tanggal: string; // ISO string
  createdAt: number;
}

export interface ServiceSetting {
  type: ServiceType;
  intervalKM: number; // interval servis dalam KM
  aktif: boolean;
}

export interface OrderRecord {
  id: string;
  nominal: number;
  platform: string;
  lat?: number;
  lng?: number;
  namaLokasi?: string;
  wilayah?: string;
  jamGacor?: string;
  timestamp: number;
  createdAt: number;
}

export interface WidgetSnapshot {
  todayNet: number;
  target: number;
  platform: string;
  platformName: string;
  quickAmount: number;
  trips: number;
  remaining: number;
  progressPct: number;
}

export interface OnboardingData {
  nama: string;
  platform: string;
  nomorKendaraan: string;
  currentKM: number;
  services: ServiceType[];
  completed: boolean;
}

export interface TimerOnBidState {
  isRunning: boolean;
  startTime: number | null;
  elapsedSeconds: number; // accumulated time from previous sessions
  totalSeconds: number;   // startTime ? elapsed + (now - start) : elapsed
  targetJam: number;      // 250 jam
}

export type GrabLevel = 'Pejuang' | 'Kesatria' | 'Jawara';

export type Page =
  | 'onboarding'
  | 'cockpit'
  | 'catat-order'
  | 'strategi'
  | 'riwayat-servis'
  | 'level-grab'
  | 'pengaturan';

export interface UserSettings {
  quickOrderNominal: number;
  platform: string;
}

export interface LevelTarget {
  hari: number;
  jam: number;
  penyelesaian: number; // %
  rating: number;
  orderan: number;
}

export interface LevelProgress {
  hari: number;
  jam: number;
  penyelesaian: number;
  rating: number;
  orderan: number;
}

export interface SpotData {
  id: string;
  lat: number;
  lng: number;
  timestamp: number;
  namaLokasi: string;
  wilayah: string;
  jamGacor: string;
  isEstimasi: boolean;
  nominal?: number;
}

export interface RegionInfo {
  nama: string;
  wilayah: 'Jaksel' | 'Jakbar' | 'Jakpus' | 'Jaktim' | 'Jakut' | 'Luar Jakarta';
}

// LEVEL GRAB TARGETS per level
export const LEVEL_TARGETS: Record<GrabLevel, LevelTarget> = {
  Pejuang: { hari: 16, jam: 176, penyelesaian: 80, rating: 4.9, orderan: 150 },
  Kesatria: { hari: 22, jam: 200, penyelesaian: 85, rating: 4.9, orderan: 200 },
  Jawara: { hari: 24, jam: 250, penyelesaian: 90, rating: 4.9, orderan: 250 },
};

// SERVICE INTERVALS (default KM between services)
export const SERVICE_INTERVALS: Record<ServiceType, number> = {
  Oli: 5000,
  Mesin: 20000,
  Kopling: 40000,
  Rem: 15000,
  Aki: 24000,
  Filter: 10000,
};

// WILAYAH DKI JAKARTA - bounding box approx
export const JAKARTA_REGIONS: RegionInfo[] = [
  { nama: 'Jakarta Selatan', wilayah: 'Jaksel' },
  { nama: 'Jakarta Barat', wilayah: 'Jakbar' },
  { nama: 'Jakarta Pusat', wilayah: 'Jakpus' },
  { nama: 'Jakarta Timur', wilayah: 'Jaktim' },
  { nama: 'Jakarta Utara', wilayah: 'Jakut' },
  { nama: 'Luar Jakarta', wilayah: 'Luar Jakarta' },
];

// JAM GACOR SLOTS
export const JAM_GACOR_SLOTS = [
  '06:00-09:00',
  '09:00-11:00',
  '11:00-13:00',
  '13:00-17:00',
  '17:00-20:00',
  '20:00-23:00',
  '23:00-06:00',
];

export const STORAGE_KEYS = {
  SERVICES: 'ojol_services',
  SERVICE_SETTINGS: 'ojol_service_settings',
  ORDERS: 'ojol_orders',
  WIDGET_SNAPSHOT: 'ojol_widget_snapshot',
  ONBOARDING: 'ojol_onboarding',
  TIMER_ONBID: 'ojol_timer_onbid',
  SPOT_DATA: 'ojol_spot_data',
  USER_SETTINGS: 'ojol_user_settings',
} as const;
