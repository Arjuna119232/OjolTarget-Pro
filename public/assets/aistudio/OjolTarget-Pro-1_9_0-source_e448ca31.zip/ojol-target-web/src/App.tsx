import { useCallback, useState } from 'react';
import { Onboarding } from './components/Onboarding';
import { Cockpit } from './components/Cockpit';
import { CatatOrder } from './components/CatatOrder';
import { StrategiSpot } from './components/StrategiSpot';
import { RiwayatServis } from './components/RiwayatServis';
import { LevelGrab } from './components/LevelGrab';
import { Pengaturan } from './components/Pengaturan';
import { NavBar } from './components/NavBar';
import { OnboardingData, Page } from '@/types';

export default function App() {
  const [page, setPage] = useState<Page>('cockpit');
  const [onboarding, setOnboarding] = useState<OnboardingData | null>(null);

  const goTo = useCallback((p: Page) => setPage(p), []);

  const selesaiOnboarding = useCallback((data: OnboardingData) => {
    setOnboarding(data);
    setPage('cockpit');
  }, []);

  // Jika belum onboarding, tunjukkan onboarding dulu
  if (!onboarding) {
    return (
      <div className="app">
        <Onboarding onSelesai={selesaiOnboarding} />
      </div>
    );
  }

  return (
    <div className="app">
      <main className="main-content">
        {page === 'cockpit' && <Cockpit onboarding={onboarding} />}
        {page === 'catat-order' && <CatatOrder onboarding={onboarding} />}
        {page === 'strategi' && <StrategiSpot />}
        {page === 'riwayat-servis' && <RiwayatServis onboarding={onboarding} />}
        {page === 'level-grab' && <LevelGrab />}
        {page === 'pengaturan' && <Pengaturan onboarding={onboarding} />}
      </main>
      <NavBar page={page} onPageChange={goTo} />
    </div>
  );
}
